/* owl-carousel */
jQuery('.owl-carousel').owlCarousel({
    loop:true,
    margin:32,
    responsiveClass:true,
    stagePadding: 300,
    autoplay: true,
    autoplayTimeout: 5000,
    dots: true,
    responsive:{
        0:{
            items:1,
            nav:true
        },
        320:{
            items:1,
            nav:true,
            dots: true,
            loop:true,
            stagePadding: 10
        },
        
        600:{
            items:1,
            nav:true,
            dots: true,
            loop:true,
            stagePadding: 100
        },
        700:{
            items:1,
            nav:true,
            dots: true,
            loop:true,
            stagePadding: 100
        },
        1024:{
            items:1,
            nav:true,
            dots: true,
            loop:true,
            stagePadding: 190

        },
        1200:{
            items:1,
            nav:true,
            dots: true,
            loop:true,
            stagePadding: 300

        },
        1900:{
            items:1,
            nav:true,
            dots: true,
            loop:true,
            stagePadding: 400

        }
    }
});
/* End */

    
/* Add/Remove class */
$('.input-desc input').focus(function () {
    $(this).closest(".input-desc").addClass('input-img');
}).blur(function () {
    $(this).closest("div.input-desc").removeClass('input-img');
});
/* End */

/* Sticky Header */
$(window).scroll(function(){
    if ($(this).scrollTop() > 150) {
       $('#myHeader').addClass('sticky');
    } else {
       $('#myHeader').removeClass('sticky');
    }
});
/* End */

/* Steps */
$(document).ready(function() {
    var navListItems = $('ul.setup-panel li a'),
        allWells = $('.setup-content'),
        allNextBtn = $('.nextBtn');

    allWells.hide();

    navListItems.click(function(e) {
        e.preventDefault();
        var $target = $($(this).attr('href')),
            $item = $(this);

        if (!$item.hasClass('disabled')) {
            navListItems.removeClass('active').addClass('btn-default');
            $item.addClass('active');
            allWells.hide();
            $target.show();
            $target.find('input:eq(0)').focus();
        }
    });

    allNextBtn.click(function() {
        var curStep = $(this).closest(".setup-content"),
            curStepBtn = curStep.attr("id"),
            nextStepWizard = $('ul.setup-panel li a[href="#' + curStepBtn + '"]').parent().next().children("a"),
            curInputs = curStep.find("input[type='text'],input[type='url']"),
            isValid = true;

        $(".form-group").removeClass("has-error");
        for (var i = 0; i < curInputs.length; i++) {
            if (!curInputs[i].validity.valid) {
                isValid = false;
                $(curInputs[i]).closest(".form-group").addClass("has-error");
            }
        }

        if (isValid)
            nextStepWizard.removeAttr('disabled').trigger('click');
    });

    $('ul.setup-panel li a.active').trigger('click');

    $('.btn-circle').click(function(){
        $('.btn-circle').each(function(){
           $(this).removeClass('completed');
        });
        var dataid = $(this).attr('data-id');
        for(var i = 1; i < dataid; i++){
            $('.btn-circle').each(function(){

                if($(this).attr('data-id') == i){
                    $(this).addClass('completed');
                } 
            });
        }
    });             
});

/* End */

/*  Tooltip */
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
/* End */

/* File Upload */
$(document).ready(function(){
  $('.ds-frm input').change(function () {
    $('.ds-frm p').text(this.files.length + " file(s) selected");
  });
});
/* End */

/* Datepicker */

// $('#datepicker').datepicker({
//         format: 'dd/mm/yyyy',
//         weekStart: 1,
//         // daysOfWeekHighlighted: "6,0",
//         autoclose: true,
//         todayHighlight: true,
//     });
//     $('#datepicker').datepicker("setDate", new Date());
/* End */